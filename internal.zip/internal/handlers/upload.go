package handlers

import (
	"net/http"

	"jevon/internal/middleware"
	"jevon/internal/repository"
	"jevon/internal/storage"

	"github.com/gin-gonic/gin"
)

type UploadHandler struct {
	storage  *storage.MinIOService
	pipeline *repository.PipelineRepo
}

func NewUploadHandler(storage *storage.MinIOService, pipeline *repository.PipelineRepo) *UploadHandler {
	return &UploadHandler{storage: storage, pipeline: pipeline}
}

// POST /api/projects/:project_id/stages/:stage_id/upload
// Загружает файлы к этапу проекта и сохраняет в БД
// Поддерживает multipart/form-data с полем "files"
// Query param: type = project | design | cutting (определяет бакет)
func (h *UploadHandler) UploadStageFiles(c *gin.Context) {
	claims    := middleware.GetClaims(c)
	projectID := c.Param("project_id")
	stageID   := c.Param("stage_id")
	uploadType := c.DefaultQuery("type", "project")

	// Парсим multipart форму (макс 50MB)
	if err := c.Request.ParseMultipartForm(50 << 20); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "failed to parse form"})
		return
	}

	uploaded, err := h.storage.UploadMultiple(
		c, c.Request.MultipartForm, uploadType, projectID,
	)
	if err != nil || len(uploaded) == 0 {
		c.JSON(http.StatusBadRequest, gin.H{"error": "no files uploaded"})
		return
	}

	// Сохраняем записи о файлах в БД
	var savedIDs []string
	for _, f := range uploaded {
		id, err := h.pipeline.CreateFile(c, projectID, stageID, claims.UserID,
			storage.ToCreateFileRequest(f))
		if err == nil {
			savedIDs = append(savedIDs, id)
		}
	}

	c.JSON(http.StatusCreated, gin.H{
		"uploaded": len(uploaded),
		"files":    uploaded,
		"ids":      savedIDs,
	})
}

// POST /api/users/avatar
// Загружает аватар текущего пользователя
func (h *UploadHandler) UploadAvatar(c *gin.Context) {
	claims := middleware.GetClaims(c)

	file, header, err := c.Request.FormFile("file")
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "file required"})
		return
	}
	defer file.Close()

	fileURL, _, err := h.storage.Upload(c, file, header, "avatar", claims.UserID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{"avatar_url": fileURL})
}

// DELETE /api/files
// Удаляет файл из MinIO по URL
func (h *UploadHandler) DeleteFile(c *gin.Context) {
	var req struct {
		FileURL string `json:"file_url" binding:"required"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	if err := h.storage.Delete(c, req.FileURL); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, gin.H{"message": "deleted"})
}
